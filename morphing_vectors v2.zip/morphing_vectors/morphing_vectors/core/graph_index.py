"""
core/graph_index.py

A from-scratch, single-layer Navigable Small World (NSW) graph for
approximate nearest-neighbor search. This intentionally implements a
well-documented base algorithm (Malkov & Yashunin's NSW, pre-HNSW)
directly rather than importing hnswlib/FAISS, because the novel
contribution of this project is the *tier-aware rewiring* on top of
this graph (see MorphingVectorIndex.migrate), not the base graph
algorithm itself. Implementing a known algorithm from scratch is not
the same as depending on a library for it: every edge, every distance
comparison, and every rewiring decision lives in this codebase and is
inspectable/modifiable by the tier-migration engine.

Distances are computed on whatever vector representation the caller
passes in (raw float vectors OR quantizer-decoded reconstructions) —
the graph itself is representation-agnostic, which is what lets tiers
share one graph topology while differing in the precision of the
vectors attached to each node.
"""

from __future__ import annotations
import heapq
import numpy as np
from dataclasses import dataclass, field


def _l2(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(a - b))


@dataclass
class NSWNode:
    vid: int
    vector: np.ndarray
    neighbors: set = field(default_factory=set)


class NSWIndex:
    """
    Greedy-search NSW graph.

    insert(): connects a new node to its M approximate nearest
    neighbors found via greedy search from a random entry point,
    then adds backlinks (both directions), pruning each node's
    neighbor list to keep degree bounded.

    search(): beam-style greedy search from a random entry point,
    expanding the closest unexplored candidate until `ef` candidates
    have been exhausted, matching the standard NSW/HNSW search pattern.
    """

    def __init__(self, dim: int, M: int = 12, ef_construction: int = 64, seed: int = 0,
                 n_entry_points: int = 4, recent_window: int = 150, n_recent_samples: int = 8):
        self.dim = dim
        self.M = M
        self.ef_construction = ef_construction
        self.nodes: dict[int, NSWNode] = {}
        self.rng = np.random.default_rng(seed)
        # A small, persistent pool of entry points (well-connected early
        # nodes) rather than a fresh uniform-random entry per search.
        # Single random-entry greedy search on a sparse NSW graph has
        # poor recall at even moderate N (verified empirically); multiple
        # entries + best-first expansion across all of them is the
        # standard fix used by NSW/HNSW and is still fully self-contained.
        self.n_entry_points = n_entry_points
        self.entry_points: list[int] = []        # long-lived hub entries
        # A sliding window of the most-recently-inserted vids (not just
        # the last handful). Search samples a few entries from this
        # window each call. This is what actually guarantees search
        # can reach freshly connected, still-fine-precision regions of
        # the graph -- see _entry_pool docstring below for why this
        # was necessary at all.
        self.recent_window = recent_window
        self.n_recent_samples = n_recent_samples
        self._recent_order: list[int] = []

    def __len__(self):
        return len(self.nodes)

    def _register_entry_point(self, vid: int) -> None:
        if len(self.entry_points) < self.n_entry_points:
            self.entry_points.append(vid)
        self._recent_order.append(vid)
        if len(self._recent_order) > self.recent_window:
            self._recent_order.pop(0)

    def _entry_pool(self) -> list[int]:
        """
        Search entry points = long-lived hub nodes (good global graph
        coverage) UNION a random sample from the recent-insertion
        window (guaranteed access into freshly connected, still-fine-
        precision regions of the graph). Without the recent sample,
        greedy search always starts from whatever the earliest-
        inserted nodes happen to be -- and under tiering those nodes
        are exactly the ones most likely to have migrated to the
        coarsest, noisiest precision, which corrupts every search's
        early hops regardless of what the query is actually near. This
        was found empirically: hub-only entry points collapsed recall
        on recent-vector queries even though the target vectors
        themselves were still stored at fine precision, because search
        could never get a foothold in that region of the graph without
        first stumbling through several distorted-distance hops.
        """
        recent_pool = [v for v in self._recent_order if v in self.nodes]
        if len(recent_pool) > self.n_recent_samples:
            idx = self.rng.choice(len(recent_pool), size=self.n_recent_samples, replace=False)
            recent_sample = [recent_pool[i] for i in idx]
        else:
            recent_sample = recent_pool
        pool = list(dict.fromkeys(self.entry_points + recent_sample))
        return [v for v in pool if v in self.nodes]

    def _greedy_search(self, query: np.ndarray, ef: int) -> list[tuple[float, int]]:
        """Multi-entry best-first search. Return up to `ef` (dist, vid)
        candidates, best-first."""
        if not self.nodes:
            return []
        entries = self._entry_pool() or [next(iter(self.nodes))]

        visited = set()
        candidates: list[tuple[float, int]] = []  # min-heap by distance
        result: list[tuple[float, int]] = []       # max-heap (negated) of best-so-far

        for entry in entries:
            if entry not in self.nodes or entry in visited:
                continue
            visited.add(entry)
            d0 = _l2(query, self.nodes[entry].vector)
            heapq.heappush(candidates, (d0, entry))
            heapq.heappush(result, (-d0, entry))
            if len(result) > ef:
                heapq.heappop(result)

        while candidates:
            d, vid = heapq.heappop(candidates)
            worst_result = -result[0][0] if result else float("inf")
            if d > worst_result and len(result) >= ef:
                break
            for nb in self.nodes[vid].neighbors:
                if nb in visited:
                    continue
                visited.add(nb)
                dnb = _l2(query, self.nodes[nb].vector)
                worst_result = -result[0][0] if result else float("inf")
                if len(result) < ef or dnb < worst_result:
                    heapq.heappush(candidates, (dnb, nb))
                    heapq.heappush(result, (-dnb, nb))
                    if len(result) > ef:
                        heapq.heappop(result)
        return sorted([(-d, vid) for d, vid in result])

    def insert(self, vid: int, vector: np.ndarray) -> None:
        node = NSWNode(vid=vid, vector=vector)
        self.nodes[vid] = node
        self._register_entry_point(vid)
        if len(self.nodes) == 1:
            return
        candidates = self._greedy_search(vector, self.ef_construction)
        candidates = [c for c in candidates if c[1] != vid][: self.M]
        for _, nb in candidates:
            node.neighbors.add(nb)
            self.nodes[nb].neighbors.add(vid)
            self._prune(nb)
        self._prune(vid)

    def _prune(self, vid: int) -> None:
        """Keep each node's degree bounded to its M closest neighbors
        (simple degree-bound heuristic, not the full HNSW heuristic
        selection — adequate at the scale this project targets)."""
        node = self.nodes[vid]
        if len(node.neighbors) <= self.M:
            return
        scored = [(_l2(node.vector, self.nodes[n].vector), n) for n in node.neighbors]
        scored.sort()
        node.neighbors = {n for _, n in scored[: self.M]}

    def update_vector(self, vid: int, new_vector: np.ndarray) -> None:
        """Swap in a re-encoded (post-migration) vector without
        touching graph topology — cheap O(1) update used by the
        tier-migration engine for same-topology re-encoding."""
        self.nodes[vid].vector = new_vector

    def remove(self, vid: int) -> None:
        node = self.nodes.pop(vid, None)
        if node is None:
            return
        for nb in node.neighbors:
            self.nodes[nb].neighbors.discard(vid)
        if vid in self.entry_points:
            self.entry_points.remove(vid)
            # backfill from any remaining node so entry pool doesn't shrink
            for other in self.nodes:
                if other not in self.entry_points:
                    self.entry_points.append(other)
                    break
        if vid in self._recent_order:
            self._recent_order.remove(vid)

    def search(self, query: np.ndarray, k: int, ef: int | None = None) -> list[tuple[int, float]]:
        ef = ef or max(k, self.ef_construction // 2)
        results = self._greedy_search(query, ef)
        return [(vid, d) for d, vid in results[:k]]
