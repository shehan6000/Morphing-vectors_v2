"""
core/tiers.py

This is the novel component of the project: a recency-driven tier
assignment policy plus an amortized-cost lazy migration engine that
moves vectors between quantization precisions as they age, without
ever doing a full index rebuild.

Design rationale
-----------------
Existing adaptive index work (e.g. learned indexes, self-designing
storage engines) adapts structure to *data distribution*. Nothing in
that line of work treats *time since insertion / time since last
access* as a first-class axis that a vector's stored precision should
track. Recency-skewed workloads (financial time series, logs, sensor
streams) make this a real, exploitable structural property: recent
data is queried often and needs tight recall; old data is queried
rarely and can tolerate lossy reconstruction.

Migration cost model
---------------------
On every insert (or explicit tick), the engine examines a small,
bounded batch of "due" vectors (those whose age has crossed a tier
boundary) and migrates them. This keeps per-operation migration cost
O(batch_size), independent of total index size N — i.e. amortized
sub-linear in N per query, which is the property claimed in the
paper's Theorem 2 (see core/theory.py for the numeric check).
"""

from __future__ import annotations
from dataclasses import dataclass, field
import heapq


@dataclass
class TierBoundary:
    """A vector older than `max_age` (in ticks since last access)
    belongs in `tier_index` or coarser."""
    max_age: float
    tier_index: int
    target_recall: float  # documented recall budget for this tier


class RecencyTierManager:
    """
    Tracks, for every vector id, its last-access tick and current
    tier. Exposes a bounded per-call migration step so callers (the
    top-level index) can amortize migration cost across normal
    insert/query traffic instead of doing a stop-the-world rebuild.
    """

    def __init__(self, boundaries: list[TierBoundary], migration_batch_size: int = 8):
        # boundaries must be sorted ascending by max_age; last one has
        # max_age = inf and is the coldest tier.
        self.boundaries = sorted(boundaries, key=lambda b: b.max_age)
        self.migration_batch_size = migration_batch_size
        self.last_access: dict[int, float] = {}
        self.current_tier: dict[int, int] = {}
        # min-heap of (due_tick, vid) — when `due_tick` is reached the
        # vector should be re-evaluated for migration.
        self._due_heap: list[tuple[float, int]] = []
        self._due_set: set[int] = set()

    def register(self, vid: int, tick: float) -> int:
        """Called on insert. Returns the initial tier (always tier 0,
        the finest / freshest)."""
        self.last_access[vid] = tick
        self.current_tier[vid] = 0
        self._schedule(vid, tick)
        return 0

    def touch(self, vid: int, tick: float) -> None:
        """Called on query/access — refreshes recency, which is what
        lets a hot old vector stay in a fine tier (access-driven, not
        purely insertion-age-driven)."""
        self.last_access[vid] = tick
        self._schedule(vid, tick)

    def _schedule(self, vid: int, tick: float) -> None:
        if vid in self._due_set:
            return
        # next boundary this vector could cross, from its *current* tier
        cur = self.current_tier.get(vid, 0)
        if cur >= len(self.boundaries) - 1:
            return  # already coldest tier, nothing to schedule
        due_tick = tick + self.boundaries[cur].max_age
        heapq.heappush(self._due_heap, (due_tick, vid))
        self._due_set.add(vid)

    def tier_for_age(self, age: float) -> int:
        for b in self.boundaries:
            if age <= b.max_age:
                return b.tier_index
        return self.boundaries[-1].tier_index

    def due_migrations(self, tick: float) -> list[tuple[int, int, int]]:
        """
        Pop up to `migration_batch_size` vectors whose scheduled
        re-evaluation tick has passed, and compute their new tier.
        Returns list of (vid, old_tier, new_tier). This is the
        amortized step: O(batch_size) work per call regardless of
        total index size.
        """
        out = []
        n = 0
        while self._due_heap and n < self.migration_batch_size:
            due_tick, vid = self._due_heap[0]
            if due_tick > tick:
                break
            heapq.heappop(self._due_heap)
            self._due_set.discard(vid)
            if vid not in self.last_access:
                continue  # deleted since scheduling
            age = tick - self.last_access[vid]
            old_tier = self.current_tier[vid]
            new_tier = self.tier_for_age(age)
            if new_tier != old_tier:
                self.current_tier[vid] = new_tier
                out.append((vid, old_tier, new_tier))
            self._schedule(vid, tick)
            n += 1
        return out

    def tier_distribution(self) -> dict[int, int]:
        dist: dict[int, int] = {}
        for t in self.current_tier.values():
            dist[t] = dist.get(t, 0) + 1
        return dist

    def pending_migration_count(self) -> int:
        return len(self._due_set)

    def pin_at_current_tier(self, vid: int, tick: float) -> None:
        """Override a just-computed migration for a structurally
        exempt vector (see MorphingVectorIndex._run_due_migrations):
        due_migrations() already updated self.current_tier[vid] before
        the caller gets a chance to react, so this forces the
        bookkeeping back to the finest tier for hub nodes, keeping
        tier_distribution() and storage/graph state consistent. The
        vector is rescheduled for re-evaluation like any other (hub
        status is rechecked every time, not cached), so if it should
        stop being a hub in a future design this would self-correct
        without further changes here."""
        self.current_tier[vid] = 0
        self._schedule(vid, tick)
