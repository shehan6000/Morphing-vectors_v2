"""
core/baseline.py

A flat, single-precision baseline built on the SAME from-scratch
components (ProductQuantizer + HNSWGraph) as MorphingVectorIndex, with
tiering disabled. This isolates the effect of recency-driven tiering
in the evaluation: same quantizer code, same graph code, same search
code — the only difference is whether vectors age into coarser tiers
or stay at one fixed precision forever. This is the fair-comparison
baseline used in eval/benchmark.py (distinct from the FAISS/DiskANN
external baselines, which test absolute competitiveness).
"""

from __future__ import annotations
import numpy as np

from .quantizer import ProductQuantizer, TierSpec
from .hnsw_graph import HNSWGraph


class FlatIndex:
    def __init__(self, dim: int, spec: TierSpec, graph_M: int = 12,
                 graph_ef_construction: int = 64, seed: int = 0):
        self.pq = ProductQuantizer(dim, spec, seed=seed)
        self.graph = HNSWGraph(dim, M=graph_M, ef_construction=graph_ef_construction, seed=seed)
        self._fitted = False
        self.codes: dict[int, np.ndarray] = {}

    def fit_quantizer(self, sample: np.ndarray) -> None:
        self.pq.fit(sample)
        self._fitted = True

    def insert(self, vid: int, vector: np.ndarray) -> None:
        assert self._fitted
        code = self.pq.encode(vector[None, :])[0]
        self.codes[vid] = code
        recon = self.pq.decode(code[None, :])[0]
        self.graph.insert(vid, recon)

    def query(self, vector: np.ndarray, k: int, ef: int | None = None) -> list[tuple[int, float]]:
        return self.graph.search(vector, k, ef=ef)

    def total_storage_bytes(self) -> float:
        return len(self.codes) * self.pq.bytes_per_vector()
