"""
core/index.py

MorphingVectorIndex: the top-level system. Combines:
  - TieredQuantizer (core/quantizer.py)   -- precision axis
  - HNSWGraph (core/hnsw_graph.py)      -- hierarchical search structure
  - RecencyTierManager (core/tiers.py)    -- recency -> tier policy
  - MorphingStorage (core/storage.py)     -- per-vector encoding state

One graph topology is shared across all tiers; only the *vector
representation* attached to each graph node changes on migration
(HNSWGraph.update_vector), which is what makes migration O(1) graph
work instead of a rebuild. This is the central systems claim of the
paper: adapting precision without touching search structure.
"""

from __future__ import annotations
import time
import numpy as np

from .quantizer import TieredQuantizer, TierSpec
from .hnsw_graph import HNSWGraph
from .tiers import RecencyTierManager, TierBoundary
from .storage import MorphingStorage


class MorphingVectorIndex:
    def __init__(
        self,
        dim: int,
        tier_specs: list[TierSpec],
        tier_boundaries: list[TierBoundary],
        graph_M: int = 12,
        graph_ef_construction: int = 64,
        migration_batch_size: int = 8,
        seed: int = 0,
    ):
        assert len(tier_specs) == len(tier_boundaries), \
            "one boundary per tier"
        self.dim = dim
        self.tq = TieredQuantizer(dim, tier_specs, seed=seed)
        self.graph = HNSWGraph(dim, M=graph_M, ef_construction=graph_ef_construction, seed=seed)
        self.tiers = RecencyTierManager(tier_boundaries, migration_batch_size=migration_batch_size)
        self.storage: MorphingStorage | None = None  # created after fit()
        self._fitted = False
        self._tick = 0.0

    def fit_quantizers(self, sample: np.ndarray) -> None:
        """Train all tier codebooks on a representative sample. In a
        streaming deployment this would be refreshed periodically;
        here it's a one-shot fit for evaluation purposes."""
        self.tq.fit(sample)
        self.storage = MorphingStorage(self.tq)
        self._fitted = True

    def _now(self) -> float:
        self._tick += 1.0
        return self._tick

    def insert(self, vid: int, vector: np.ndarray) -> None:
        assert self._fitted, "call fit_quantizers() before inserting"
        tick = self._now()
        self.storage.store(vid, vector, tick)
        self.tiers.register(vid, tick)
        # graph node holds the *finest*-tier reconstruction (tier 0),
        # matching what storage currently has for a freshly inserted vector.
        recon = self.storage.reconstruct(vid)
        self.graph.insert(vid, recon)
        self._run_due_migrations(tick)

    def query(self, vector: np.ndarray, k: int, ef: int | None = None) -> list[tuple[int, float]]:
        assert self._fitted, "call fit_quantizers() before querying"
        tick = self._now()
        results = self.graph.search(vector, k, ef=ef)
        for vid, _ in results:
            self.tiers.touch(vid, tick)  # hot vectors get their recency refreshed
        self._run_due_migrations(tick)
        return results

    def _run_due_migrations(self, tick: float) -> int:
        """Apply due tier transitions, with one structural exemption:
        nodes that participate in layer >= 1 of the hierarchical graph
        (HNSWGraph.is_hub) are routing infrastructure, not ordinary
        leaf data -- every query that passes through the upper layers
        depends on their vectors being accurate. A direct N=20,000
        scaling run surfaced this concretely: after replacing the
        original single-layer graph with a proper hierarchical one
        (Section 5.6 of the paper), recall got WORSE, not better,
        because the hierarchy's single entry point and upper-layer
        hubs were themselves being coarsened by the same age-based
        policy as ordinary vectors, corrupting top-down routing for
        every single query regardless of what the query targeted. This
        is the same underlying failure mode as the original entry-
        point-staleness finding, recurring in a structurally more
        damaging place (all queries route through these nodes, not
        just queries near them). The fix: hub nodes are pinned at the
        finest tier for as long as they remain hubs, and are excluded
        from the due-migration batch entirely. This does cost some
        storage -- the paper reports exactly how much (Section 5.6) --
        but is required for the hierarchy to function as intended."""
        due = self.tiers.due_migrations(tick)
        skipped = 0
        for vid, old_tier, new_tier in due:
            if self.graph.is_hub(vid):
                self.tiers.pin_at_current_tier(vid, tick)
                skipped += 1
                continue
            self.storage.reencode(vid, new_tier, tick)
            new_vec = self.storage.reconstruct(vid)
            self.graph.update_vector(vid, new_vec)  # O(1): topology untouched
        return len(due) - skipped

    def force_advance(self, ticks: int) -> int:
        """Test/benchmark helper: advance the clock without inserting
        or querying, running migration sweeps as if time passed idly."""
        total_migrated = 0
        for _ in range(ticks):
            tick = self._now()
            total_migrated += self._run_due_migrations(tick)
        return total_migrated

    def stats(self) -> dict:
        return {
            "n_vectors": len(self.graph),
            "tier_distribution": self.tiers.tier_distribution(),
            "total_storage_bytes": self.storage.total_storage_bytes() if self.storage else 0,
            "migration_count": self.storage.migration_count if self.storage else 0,
            "bytes_saved_by_migration": self.storage.bytes_saved_by_migration if self.storage else 0,
            "pending_migrations": self.tiers.pending_migration_count(),
        }
