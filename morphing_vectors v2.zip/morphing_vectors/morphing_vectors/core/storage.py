"""
core/storage.py

Storage-layer bookkeeping for tiered vectors. This is deliberately the
same conceptual move as Morphing Pages' encoding-transition logic
(fine-grained, recency-driven changes to how a stored unit is encoded)
applied to vectors instead of columnar pages: each stored item carries
metadata about its current encoding (here: quantization tier + codes),
and re-encoding is a targeted, local operation rather than a bulk
rewrite. This module is what makes the "one architecture, two papers"
narrative concrete rather than just an analogy.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass


@dataclass
class StoredVector:
    vid: int
    tier: int
    codes: np.ndarray          # quantized codes at `tier`'s precision
    inserted_at: float
    last_encoded_at: float


class MorphingStorage:
    """
    Owns the physical representation of every vector: which tier it's
    encoded at right now, and its codes at that tier. Re-encoding
    (triggered by the tier-migration engine) touches only the affected
    vector's entry — no bulk rewrite, mirroring the page-level
    granularity of the Morphing Pages transitions.
    """

    def __init__(self, tiered_quantizer):
        self.tq = tiered_quantizer
        self.records: dict[int, StoredVector] = {}
        self.migration_count = 0
        self.bytes_saved_by_migration = 0.0

    def store(self, vid: int, vector: np.ndarray, tick: float) -> None:
        codes = self.tq.encode(0, vector[None, :])[0]
        self.records[vid] = StoredVector(
            vid=vid, tier=0, codes=codes, inserted_at=tick, last_encoded_at=tick
        )

    def reencode(self, vid: int, new_tier: int, tick: float) -> None:
        rec = self.records[vid]
        old_bytes = self.tq.bytes_per_vector(rec.tier)
        new_codes = self.tq.reencode(rec.tier, new_tier, rec.codes[None, :])[0]
        new_bytes = self.tq.bytes_per_vector(new_tier)
        self.bytes_saved_by_migration += max(0.0, old_bytes - new_bytes)
        rec.tier = new_tier
        rec.codes = new_codes
        rec.last_encoded_at = tick
        self.migration_count += 1

    def reconstruct(self, vid: int) -> np.ndarray:
        rec = self.records[vid]
        return self.tq.decode(rec.tier, rec.codes[None, :])[0]

    def total_storage_bytes(self) -> float:
        return sum(self.tq.bytes_per_vector(r.tier) for r in self.records.values())

    def tier_of(self, vid: int) -> int:
        return self.records[vid].tier
