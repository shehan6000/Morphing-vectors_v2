"""
core/theory.py

Formal claims and their numeric validation. Written up here so the
paper's theory section and the code that checks it live next to each
other — TKDE reviewers can be pointed at exact functions.

--------------------------------------------------------------------
Theorem 1 (Recall-decay bound under tiered quantization).

Let q_t be the quantization error (mean L2 reconstruction error, as
computed by ProductQuantizer.reconstruction_error) of tier t, and let
delta be the true nearest-neighbor margin for a query — i.e. the gap
between the true k-th nearest neighbor distance and the (k+1)-th. If a
database vector v is stored at tier t with reconstruction error q_t,
then a query can fail to retrieve v within its top-k set only if the
distance distortion introduced by quantization exceeds delta/2 (by
the triangle inequality applied to the quantization error on both the
query side, if quantized, and the stored side):

    P(recall miss due to tier t storage) <= P(q_t > delta / 2)

Since coarser tiers (larger max_age boundary) have strictly larger
q_t (monotonic in the number of subquantizers/bits — verified
empirically in validate_monotonic_error below, and true by
construction since a coarser codebook is a special case of a finer
one's quantization cells merged), recall degrades monotonically with
tier coldness. This gives the paper's core justification for the
recency -> tier -> recall-budget mapping: choosing max_age boundaries
is equivalent to choosing an acceptable P(recall miss) per age band.

--------------------------------------------------------------------
Theorem 2 (Amortized migration cost).

Each insert schedules at most one due-entry in the tier manager's
heap (RecencyTierManager._schedule). due_migrations() pops and
processes at most `migration_batch_size` entries per call, each in
O(log N) heap time plus O(1) re-encode (re-encode cost is
independent of N — it only touches the migrating vector's codes).
Therefore the amortized migration cost per index operation is
O(migration_batch_size * log N), independent of the *number* of
vectors migrating across the whole index at any given tick — i.e.
sub-linear in N and never a full-index rebuild. This is checked
empirically in eval/benchmark.py by tracking migration wall-clock
time as N grows.
--------------------------------------------------------------------
"""

from __future__ import annotations
import numpy as np


def validate_monotonic_error(tiered_quantizer, data: np.ndarray) -> list[float]:
    """Empirically confirm q_t is non-decreasing as tiers get coarser
    (tier 0 = finest -> last tier = coarsest). Returns the list of
    per-tier mean reconstruction errors so the paper can plot it."""
    errors = [tiered_quantizer.error_of_tier(t, data) for t in range(len(tiered_quantizer.quantizers))]
    for i in range(1, len(errors)):
        assert errors[i] >= errors[i - 1] - 1e-6, (
            f"tier {i} error {errors[i]:.4f} is not >= tier {i-1} error {errors[i-1]:.4f}; "
            "tier specs should be strictly non-increasing in (n_subquantizers, bits)"
        )
    return errors


def empirical_recall_miss_rate(true_neighbors: np.ndarray, retrieved_neighbors: np.ndarray) -> float:
    """1 - recall@k, used to check Theorem 1's predicted ordering
    (coarser tier -> higher miss rate) against actual query results."""
    n = true_neighbors.shape[0]
    hits = 0
    for i in range(n):
        hits += len(set(true_neighbors[i].tolist()) & set(retrieved_neighbors[i].tolist()))
    total = true_neighbors.size
    return 1.0 - hits / total
