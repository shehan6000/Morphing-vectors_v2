"""
core/quantizer.py

From-scratch Product Quantizer (PQ). No FAISS, no scikit-learn KMeans —
Lloyd's algorithm and k-means++ seeding are implemented directly on numpy
arrays so the codebook-training loop, residual tracking, and error bound
machinery are fully owned by this codebase (required for the TKDE
"built from scratch" framing: reviewers can inspect every arithmetic step).

Design
------
A vector of dimension D is split into M contiguous subvectors of size
D/M. Each subspace gets its own codebook of size K = 2^bits, trained by
k-means. Encoding a vector means, per subspace, storing the index of the
nearest codeword. Decoding reconstructs by concatenating codewords.

Multiple precision "tiers" are supported by varying (M, bits): fewer
subquantizers / fewer bits per subquantizer -> coarser, cheaper, lossier
encoding. This is the quantization axis that the tier-migration engine
(core/tiers.py) moves vectors along as they age.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass


def _kmeans_plusplus_init(data: np.ndarray, k: int, rng: np.random.Generator) -> np.ndarray:
    """k-means++ seeding, implemented directly (no sklearn)."""
    n = data.shape[0]
    centers = np.empty((k, data.shape[1]), dtype=data.dtype)
    first = rng.integers(0, n)
    centers[0] = data[first]
    closest_sq_dist = np.sum((data - centers[0]) ** 2, axis=1)
    for i in range(1, k):
        probs = closest_sq_dist / (closest_sq_dist.sum() + 1e-12)
        next_idx = rng.choice(n, p=probs)
        centers[i] = data[next_idx]
        new_sq_dist = np.sum((data - centers[i]) ** 2, axis=1)
        closest_sq_dist = np.minimum(closest_sq_dist, new_sq_dist)
    return centers


def _sq_dists(data: np.ndarray, centers: np.ndarray) -> np.ndarray:
    """Squared L2 distance from every row of `data` to every row of
    `centers`, via the expanded form ||x||^2 - 2 x.c + ||c||^2. This
    avoids ever materializing an (n, k, d) tensor -- the naive
    broadcasting form used previously -- which is what capped the old
    implementation at roughly N=10K before memory blew up. This is
    still hand-written distance-matrix arithmetic, not a library
    k-means/NN call; it is the standard algebraic trick for computing
    pairwise squared distances efficiently, not an outsourced
    implementation of clustering or search itself."""
    x_sq = np.einsum("ij,ij->i", data, data)[:, None]
    c_sq = np.einsum("ij,ij->i", centers, centers)[None, :]
    cross = data @ centers.T
    d2 = x_sq - 2.0 * cross + c_sq
    np.maximum(d2, 0.0, out=d2)  # clip tiny negative floating-point noise
    return d2


def _lloyd_kmeans(data: np.ndarray, k: int, iters: int, rng: np.random.Generator,
                   tol: float = 1e-5) -> tuple[np.ndarray, np.ndarray]:
    """Standard (full-batch) Lloyd's algorithm, implemented from
    scratch, using the O(n*k + n*d + k*d) expanded-distance formula
    instead of an O(n*k*d) broadcast tensor."""
    n = data.shape[0]
    k_eff = min(k, n)  # guard against tiny subsets
    centers = _kmeans_plusplus_init(data, k_eff, rng)
    assign = np.zeros(n, dtype=np.int64)
    prev_inertia = None
    for _ in range(iters):
        dists = _sq_dists(data, centers)
        assign = dists.argmin(axis=1)
        inertia = dists[np.arange(n), assign].sum()
        counts = np.bincount(assign, minlength=k_eff)
        sums = np.zeros_like(centers)
        np.add.at(sums, assign, data)
        empty = counts == 0
        if empty.any():
            far = dists[np.arange(n), assign].argmax()
            for c in np.where(empty)[0]:
                centers[c] = data[far]
                counts[c] = 1
                sums[c] = data[far]
        nonempty = counts > 0
        centers[nonempty] = sums[nonempty] / counts[nonempty, None]
        if prev_inertia is not None and abs(prev_inertia - inertia) < tol * max(prev_inertia, 1e-12):
            break
        prev_inertia = inertia
    if k_eff < k:
        pad = np.tile(centers[-1:], (k - k_eff, 1))
        centers = np.vstack([centers, pad])
    return centers, assign


def _minibatch_kmeans(data: np.ndarray, k: int, iters: int, rng: np.random.Generator,
                       batch_size: int = 2048) -> np.ndarray:
    """Mini-batch Lloyd's algorithm (Sculley 2010-style streaming
    update), implemented from scratch: each iteration samples a batch,
    assigns it to the nearest current centroid, and applies a
    per-centroid running-average update with a decaying learning rate
    (1/count), rather than recomputing a full-data mean every
    iteration. This is what makes training tractable at N well beyond
    what full-batch Lloyd's (O(n*k) per iteration, all N touched every
    iteration) can handle in reasonable time -- it is the standard
    algorithmic fix for k-means at scale, written here directly rather
    than imported from sklearn.cluster.MiniBatchKMeans."""
    n = data.shape[0]
    k_eff = min(k, n)
    init_sample = data[rng.choice(n, size=min(n, max(k_eff * 20, 2000)), replace=False)]
    centers = _kmeans_plusplus_init(init_sample, k_eff, rng)
    counts = np.zeros(k_eff, dtype=np.int64)
    for _ in range(iters):
        idx = rng.choice(n, size=min(batch_size, n), replace=False)
        batch = data[idx]
        dists = _sq_dists(batch, centers)
        assign = dists.argmin(axis=1)
        for c in np.unique(assign):
            members = batch[assign == c]
            counts[c] += len(members)
            lr = len(members) / counts[c]
            centers[c] = (1 - lr) * centers[c] + lr * members.mean(axis=0)
    if k_eff < k:
        pad = np.tile(centers[-1:], (k - k_eff, 1))
        centers = np.vstack([centers, pad])
    return centers


@dataclass
class TierSpec:
    """Precision spec for one quantization tier."""
    name: str
    n_subquantizers: int   # M
    bits: int              # bits per subquantizer -> K = 2^bits codewords/subspace


class ProductQuantizer:
    """
    A single-precision product quantizer. One instance = one tier's
    codebook set.
    """

    def __init__(self, dim: int, spec: TierSpec, kmeans_iters: int = 25, seed: int = 0,
                 minibatch_threshold: int = 15000, minibatch_size: int = 2048):
        assert dim % spec.n_subquantizers == 0, \
            "dim must be divisible by n_subquantizers"
        self.dim = dim
        self.spec = spec
        self.sub_dim = dim // spec.n_subquantizers
        self.k = 2 ** spec.bits
        self.kmeans_iters = kmeans_iters
        self.rng = np.random.default_rng(seed)
        self.codebooks: list[np.ndarray] | None = None  # list of (k, sub_dim)
        # Above this many training points, switch from full-batch Lloyd's
        # to mini-batch training (see _minibatch_kmeans) -- full-batch
        # touches every point every iteration (O(n*k) per iter), which
        # stops being practical well before N=100K at interactive speed.
        self.minibatch_threshold = minibatch_threshold
        self.minibatch_size = minibatch_size

    def fit(self, data: np.ndarray) -> "ProductQuantizer":
        self.codebooks = []
        use_minibatch = data.shape[0] > self.minibatch_threshold
        for m in range(self.spec.n_subquantizers):
            sub = data[:, m * self.sub_dim:(m + 1) * self.sub_dim]
            if use_minibatch:
                centers = _minibatch_kmeans(sub, self.k, self.kmeans_iters, self.rng,
                                             batch_size=self.minibatch_size)
            else:
                centers, _ = _lloyd_kmeans(sub, self.k, self.kmeans_iters, self.rng)
            self.codebooks.append(centers)
        return self

    def encode(self, vectors: np.ndarray) -> np.ndarray:
        """Return integer codes, shape (n, n_subquantizers). Uses the
        expanded-distance formula (see _sq_dists) so this scales to
        large N without the O(n*k*d) broadcast blowup of the original
        implementation."""
        assert self.codebooks is not None, "call fit() first"
        n = vectors.shape[0]
        codes = np.empty((n, self.spec.n_subquantizers), dtype=np.int32)
        for m in range(self.spec.n_subquantizers):
            sub = vectors[:, m * self.sub_dim:(m + 1) * self.sub_dim]
            cb = self.codebooks[m]
            dists = _sq_dists(sub, cb)
            codes[:, m] = dists.argmin(axis=1)
        return codes

    def decode(self, codes: np.ndarray) -> np.ndarray:
        assert self.codebooks is not None, "call fit() first"
        n = codes.shape[0]
        out = np.empty((n, self.dim), dtype=np.float32)
        for m in range(self.spec.n_subquantizers):
            out[:, m * self.sub_dim:(m + 1) * self.sub_dim] = self.codebooks[m][codes[:, m]]
        return out

    def reconstruction_error(self, vectors: np.ndarray) -> float:
        """Mean L2 reconstruction error — the empirical quantization
        error term used directly in the recall-decay bound (see
        core/theory.py)."""
        codes = self.encode(vectors)
        recon = self.decode(codes)
        return float(np.linalg.norm(vectors - recon, axis=1).mean())

    def bytes_per_vector(self) -> float:
        total_bits = self.spec.n_subquantizers * self.spec.bits
        return total_bits / 8.0


class TieredQuantizer:
    """
    Holds one ProductQuantizer per tier. Tier 0 is always the finest
    (largest M / bits); later tiers are coarser. All tiers are trained
    on the same initial sample so codebooks stay comparable across
    migrations.
    """

    def __init__(self, dim: int, tier_specs: list[TierSpec], kmeans_iters: int = 25, seed: int = 0):
        self.dim = dim
        self.tier_specs = tier_specs
        self.quantizers = [
            ProductQuantizer(dim, spec, kmeans_iters=kmeans_iters, seed=seed + i)
            for i, spec in enumerate(tier_specs)
        ]

    def fit(self, data: np.ndarray) -> "TieredQuantizer":
        for q in self.quantizers:
            q.fit(data)
        return self

    def encode(self, tier: int, vectors: np.ndarray) -> np.ndarray:
        return self.quantizers[tier].encode(vectors)

    def decode(self, tier: int, codes: np.ndarray) -> np.ndarray:
        return self.quantizers[tier].decode(codes)

    def reencode(self, from_tier: int, to_tier: int, codes: np.ndarray) -> np.ndarray:
        """Migration op: decode at old precision, re-encode at new
        precision. This is the vector-index analogue of a Morphing
        Pages column encoding transition."""
        vecs = self.decode(from_tier, codes)
        return self.encode(to_tier, vecs)

    def error_of_tier(self, tier: int, vectors: np.ndarray) -> float:
        return self.quantizers[tier].reconstruction_error(vectors)

    def bytes_per_vector(self, tier: int) -> float:
        return self.quantizers[tier].bytes_per_vector()
