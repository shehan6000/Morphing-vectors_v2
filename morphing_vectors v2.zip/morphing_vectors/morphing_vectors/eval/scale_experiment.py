"""
eval/scale_experiment.py

Runs the actual from-scratch system (unmodified core/*) at scales
closer to what a TKDE reviewer expects (tens of thousands of vectors,
not 1,500), and separately runs FAISS as an EXTERNAL REFERENCE POINT
ONLY -- to sanity-check that this system's absolute numbers are not
pathologically far from a production library, not as a baseline the
paper's tiering claim is measured against (that comparison, Table 1
in the paper, stays FlatFine/FlatCoarse built from the SAME from-scratch
components, so it isolates the effect of tiering itself).
"""

from __future__ import annotations
import time
import json
import numpy as np

from core import MorphingVectorIndex, FlatIndex, TierSpec, TierBoundary
from eval.benchmark import (
    temporally_correlated_data, brute_force_knn, recency_skewed_workload, _recall_by_age
)


def run_at_scale(n_vectors: int, dim: int = 32, n_train_sample: int = 3000,
                  n_queries: int = 300, hot_fraction: float = 0.8, k: int = 10,
                  seed: int = 42) -> dict:
    rng = np.random.default_rng(seed)
    t_gen0 = time.perf_counter()
    data = temporally_correlated_data(n_vectors, dim, rng)
    t_gen = time.perf_counter() - t_gen0

    tier_specs = [
        TierSpec("hot", n_subquantizers=16, bits=8),
        TierSpec("warm", n_subquantizers=8, bits=5),
        TierSpec("cold", n_subquantizers=2, bits=4),
    ]
    tier_boundaries = [
        TierBoundary(max_age=150, tier_index=0, target_recall=0.95),
        TierBoundary(max_age=500, tier_index=1, target_recall=0.75),
        TierBoundary(max_age=float("inf"), tier_index=2, target_recall=0.50),
    ]
    graph_M, graph_ef_construction, query_ef = 16, 100, 150

    t_fit0 = time.perf_counter()
    morph = MorphingVectorIndex(dim, tier_specs, tier_boundaries, migration_batch_size=20,
                                 graph_M=graph_M, graph_ef_construction=graph_ef_construction, seed=seed)
    morph.fit_quantizers(data[:n_train_sample])
    flat_fine = FlatIndex(dim, tier_specs[0], graph_M=graph_M,
                           graph_ef_construction=graph_ef_construction, seed=seed)
    flat_fine.fit_quantizer(data[:n_train_sample])
    flat_coarse = FlatIndex(dim, tier_specs[-1], graph_M=graph_M,
                             graph_ef_construction=graph_ef_construction, seed=seed)
    flat_coarse.fit_quantizer(data[:n_train_sample])
    t_fit = time.perf_counter() - t_fit0

    migration_times = []
    t_insert0 = time.perf_counter()
    for i in range(n_vectors):
        t0 = time.perf_counter()
        morph.insert(i, data[i])
        migration_times.append(time.perf_counter() - t0)
        flat_fine.insert(i, data[i])
        flat_coarse.insert(i, data[i])
    t_insert = time.perf_counter() - t_insert0

    targets = recency_skewed_workload(n_vectors, n_queries, hot_fraction, rng)
    results = {"morph": [], "flat_fine": [], "flat_coarse": []}
    ages_at_query = []
    t_query0 = time.perf_counter()
    for t in targets:
        noise = rng.standard_normal(dim).astype(np.float32) * 0.05
        q = data[t] + noise
        gt = brute_force_knn(data, q, k)
        for name, sys_ in (("morph", morph), ("flat_fine", flat_fine), ("flat_coarse", flat_coarse)):
            res = sys_.query(q, k, ef=query_ef)
            retrieved = np.array([vid for vid, _ in res])
            hit = len(set(gt.tolist()) & set(retrieved.tolist()))
            results[name].append(hit / k)
        ages_at_query.append(n_vectors - t)
    t_query = time.perf_counter() - t_query0

    stats = morph.stats()
    steady_state = migration_times[-max(1, n_vectors // 10):]
    out = {
        "n_vectors": n_vectors,
        "recall": {name: float(np.mean(v)) for name, v in results.items()},
        "recall_by_age": _recall_by_age(results["morph"], ages_at_query),
        "storage_bytes": {
            "morph": stats["total_storage_bytes"],
            "flat_fine": flat_fine.total_storage_bytes(),
            "flat_coarse": flat_coarse.total_storage_bytes(),
        },
        "migration_count": stats["migration_count"],
        "timing_seconds": {
            "data_gen": t_gen, "quantizer_fit": t_fit,
            "insert_total": t_insert, "query_total": t_query,
        },
        "steady_state_insert_ms": float(np.mean(steady_state) * 1000),
        "mean_query_ms": float(t_query / n_queries * 1000),
    }
    return out


def faiss_reference_point(n_vectors: int, dim: int = 32, seed: int = 42) -> dict:
    """External sanity check only -- how does a production ANN library
    perform on data of this size/shape? Not used anywhere in the
    paper's core tiering claim (Table 1), which compares only
    from-scratch components against each other."""
    import faiss
    rng = np.random.default_rng(seed)
    data = temporally_correlated_data(n_vectors, dim, rng).astype("float32")

    t0 = time.perf_counter()
    index = faiss.IndexHNSWFlat(dim, 16)
    index.hnsw.efConstruction = 100
    index.add(data)
    build_s = time.perf_counter() - t0

    index.hnsw.efSearch = 150
    q = data[-300:] + rng.standard_normal((300, dim)).astype("float32") * 0.05
    t0 = time.perf_counter()
    D, I = index.search(q, 10)
    query_s = time.perf_counter() - t0

    return {
        "n_vectors": n_vectors,
        "faiss_hnsw_build_seconds": build_s,
        "faiss_hnsw_mean_query_ms": query_s / 300 * 1000,
    }


if __name__ == "__main__":
    all_results = {}
    for n in [5000, 20000, 50000]:
        print(f"--- running at N={n} ---", flush=True)
        res = run_at_scale(n_vectors=n)
        all_results[f"morphing_vectors_N{n}"] = res
        print(json.dumps(res, indent=2), flush=True)

    for n in [5000, 20000, 50000]:
        print(f"--- FAISS reference at N={n} ---", flush=True)
        ref = faiss_reference_point(n_vectors=n)
        all_results[f"faiss_reference_N{n}"] = ref
        print(json.dumps(ref, indent=2), flush=True)

    with open("eval/scale_results.json", "w") as f:
        json.dump(all_results, f, indent=2)
