"""
eval/benchmark.py

Evaluation harness. Three things are measured, matching the paper's
claims:

  1. Recall@k over time, split by vector age band, for
     MorphingVectorIndex vs. two baselines:
       - FlatFine:   FlatIndex at the finest precision always (upper
                      bound on quality, upper bound on storage cost)
       - FlatCoarse: FlatIndex at the coarsest precision always
                      (lower bound on storage, lower bound on quality)
     MorphingVectorIndex should track FlatFine's recall on *recent*
     queries and FlatCoarse's storage footprint on the *whole* dataset
     — that gap is the entire point of the paper.

  2. Storage footprint over time (bytes), same three systems.

  3. Migration overhead: wall-clock cost of due_migrations() calls as
     N grows, to empirically support Theorem 2 (amortized, not
     linear-in-N, cost).

Ground truth for recall is brute-force exact k-NN on the *original*
unquantized vectors — this is what "recall@k" is measured against
throughout.
"""

from __future__ import annotations
import time
import numpy as np

from core import MorphingVectorIndex, FlatIndex, TierSpec, TierBoundary


def temporally_correlated_data(n_vectors: int, dim: int, rng: np.random.Generator,
                                drift_step: float = 0.15, noise_std: float = 0.3) -> np.ndarray:
    """
    Generate vectors with temporal locality: a slowly drifting center
    (random walk in R^dim) plus per-vector noise around that center at
    each timestep. This is the property that makes recency-based
    tiering meaningful at all -- pure i.i.d. vectors (the first version
    of this benchmark used those) have NO correlation between
    insertion order and spatial position, so a "recent" query's true
    nearest neighbors are scattered uniformly across all ages including
    long-cold ones, which silently breaks the entire premise being
    tested. Financial time-series embeddings exhibit exactly this kind
    of regime persistence -- recent data resembles other recent data
    more than it resembles data from a different, earlier regime --
    which is the actual motivating scenario for this design.
    """
    center = np.zeros(dim, dtype=np.float32)
    data = np.empty((n_vectors, dim), dtype=np.float32)
    for t in range(n_vectors):
        center = center + rng.standard_normal(dim).astype(np.float32) * drift_step
        data[t] = center + rng.standard_normal(dim).astype(np.float32) * noise_std
    return data


def brute_force_knn(data: np.ndarray, query: np.ndarray, k: int) -> np.ndarray:
    d = np.linalg.norm(data - query[None, :], axis=1)
    return np.argsort(d)[:k]


def recency_skewed_workload(n_vectors: int, n_queries: int, hot_fraction: float,
                             rng: np.random.Generator) -> np.ndarray:
    """
    Generate query targets (as vector ids to be inserted, then later
    queried near) such that `hot_fraction` of queries target the most
    recently inserted 10% of the dataset, and the remainder target
    uniformly across all ages. This is the recency skew assumption the
    whole design is built around, made explicit and reproducible.
    """
    hot_window = max(1, int(0.1 * n_vectors))
    n_hot_queries = int(n_queries * hot_fraction)
    n_cold_queries = n_queries - n_hot_queries
    hot_targets = rng.integers(n_vectors - hot_window, n_vectors, size=n_hot_queries)
    cold_targets = rng.integers(0, n_vectors, size=n_cold_queries)
    targets = np.concatenate([hot_targets, cold_targets])
    rng.shuffle(targets)
    return targets


def run_benchmark(
    dim: int = 32,
    n_vectors: int = 1500,
    n_train_sample: int = 300,
    n_queries: int = 150,
    hot_fraction: float = 0.8,
    k: int = 10,
    seed: int = 42,
) -> dict:
    rng = np.random.default_rng(seed)
    data = temporally_correlated_data(n_vectors, dim, rng)

    tier_specs = [
        TierSpec("hot", n_subquantizers=16, bits=8),   # ~0.16 mean L2 err, 16 B/vec
        TierSpec("warm", n_subquantizers=8, bits=5),    # ~2.5 mean L2 err, 5 B/vec
        TierSpec("cold", n_subquantizers=2, bits=4),    # ~4.75 mean L2 err, 1 B/vec
    ]
    tier_boundaries = [
        TierBoundary(max_age=150, tier_index=0, target_recall=0.95),
        TierBoundary(max_age=500, tier_index=1, target_recall=0.75),
        TierBoundary(max_age=float("inf"), tier_index=2, target_recall=0.50),
    ]

    graph_M, graph_ef_construction, query_ef = 16, 100, 150

    morph = MorphingVectorIndex(dim, tier_specs, tier_boundaries, migration_batch_size=10,
                                 graph_M=graph_M, graph_ef_construction=graph_ef_construction, seed=seed)
    morph.fit_quantizers(data[:n_train_sample])

    flat_fine = FlatIndex(dim, tier_specs[0], graph_M=graph_M,
                           graph_ef_construction=graph_ef_construction, seed=seed)
    flat_fine.fit_quantizer(data[:n_train_sample])

    flat_coarse = FlatIndex(dim, tier_specs[-1], graph_M=graph_M,
                             graph_ef_construction=graph_ef_construction, seed=seed)
    flat_coarse.fit_quantizer(data[:n_train_sample])

    # --- Insert phase, with per-insert migration timing for Theorem 2 ---
    migration_times = []
    for i in range(n_vectors):
        t0 = time.perf_counter()
        morph.insert(i, data[i])
        migration_times.append(time.perf_counter() - t0)
        flat_fine.insert(i, data[i])
        flat_coarse.insert(i, data[i])

    # NOTE: no bulk force_advance() here. Aging happens naturally as
    # ticks accumulate during the insert loop itself (each insert
    # advances the clock by 1) -- early-inserted vectors are already
    # old by the time later ones arrive. Bulk-advancing the clock here
    # would uniformly age *everything*, including the vectors that
    # were just inserted, which defeats the recency-skew premise being
    # tested (a naive version of this benchmark did exactly that bug).

    # --- Query phase ---
    targets = recency_skewed_workload(n_vectors, n_queries, hot_fraction, rng)
    results = {"morph": [], "flat_fine": [], "flat_coarse": []}
    ages_at_query = []

    for t in targets:
        noise = rng.standard_normal(dim).astype(np.float32) * 0.05
        q = data[t] + noise
        gt = brute_force_knn(data, q, k)

        for name, sys_ in (("morph", morph), ("flat_fine", flat_fine), ("flat_coarse", flat_coarse)):
            res = sys_.query(q, k, ef=query_ef)
            retrieved = np.array([vid for vid, _ in res])
            hit = len(set(gt.tolist()) & set(retrieved.tolist()))
            results[name].append(hit / k)

        ages_at_query.append(n_vectors - t)  # proxy for how "old" the target vector was at insert time

    stats = morph.stats()
    out = {
        "recall": {name: float(np.mean(v)) for name, v in results.items()},
        "recall_by_age": _recall_by_age(results["morph"], ages_at_query),
        "storage_bytes": {
            "morph": stats["total_storage_bytes"],
            "flat_fine": flat_fine.total_storage_bytes(),
            "flat_coarse": flat_coarse.total_storage_bytes(),
        },
        "tier_distribution": stats["tier_distribution"],
        "migration_count": stats["migration_count"],
        "bytes_saved_by_migration": stats["bytes_saved_by_migration"],
        "mean_insert_time_ms": float(np.mean(migration_times) * 1000),
        "insert_time_trend_first_vs_last_100_ms": (
            float(np.mean(migration_times[:100]) * 1000),
            float(np.mean(migration_times[-100:]) * 1000),
        ),
    }
    return out


def _recall_by_age(morph_recalls: list[float], ages: list[int]) -> dict:
    ages = np.array(ages)
    recalls = np.array(morph_recalls)
    bands = {
        "recent (age<150)": (ages < 150),
        "mid (150<=age<500)": (ages >= 150) & (ages < 500),
        "old (age>=500)": (ages >= 500),
    }
    out = {}
    for label, mask in bands.items():
        if mask.sum() > 0:
            out[label] = float(recalls[mask].mean())
        else:
            out[label] = None
    return out


if __name__ == "__main__":
    result = run_benchmark()
    import json
    print(json.dumps(result, indent=2))
