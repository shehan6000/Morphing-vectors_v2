"""
eval/scaling_test.py

Empirical check for Theorem 2 (core/theory.py): mean per-insert
migration overhead should stay roughly flat as N grows, not scale
linearly with N. We run insert-only phases at several N and report
the mean wall-clock cost of the migration step alone.
"""
from __future__ import annotations
import time
import numpy as np

from core import MorphingVectorIndex, TierSpec, TierBoundary
from eval.benchmark import temporally_correlated_data


def run_scaling_test(sizes=(500, 1000, 2000, 4000, 8000), dim=32, seed=7):
    rng = np.random.default_rng(seed)
    out = {}
    for n in sizes:
        data = temporally_correlated_data(n, dim, rng)
        tier_specs = [
            TierSpec("hot", n_subquantizers=16, bits=8),
            TierSpec("warm", n_subquantizers=8, bits=5),
            TierSpec("cold", n_subquantizers=2, bits=4),
        ]
        tier_boundaries = [
            TierBoundary(max_age=150, tier_index=0, target_recall=0.95),
            TierBoundary(max_age=500, tier_index=1, target_recall=0.75),
            TierBoundary(max_age=float("inf"), tier_index=2, target_recall=0.50),
        ]
        idx = MorphingVectorIndex(dim, tier_specs, tier_boundaries, migration_batch_size=10, seed=seed)
        idx.fit_quantizers(data[: min(300, n // 2)])

        migration_times = []
        for i in range(n):
            t0 = time.perf_counter()
            idx.insert(i, data[i])
            migration_times.append(time.perf_counter() - t0)

        # measure the last 200 inserts' per-op cost as the "steady state" figure
        steady = migration_times[-200:] if n >= 200 else migration_times
        out[n] = {
            "mean_ms_all": float(np.mean(migration_times) * 1000),
            "mean_ms_steady_state": float(np.mean(steady) * 1000),
            "migration_count": idx.storage.migration_count,
        }
    return out


if __name__ == "__main__":
    import json
    print(json.dumps(run_scaling_test(), indent=2))
