"""
tests/test_basic.py

Run with: python3 -m pytest tests/ -v
(or, with no pytest installed: python3 tests/test_basic.py)
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import numpy as np
from core import (
    ProductQuantizer, TieredQuantizer, TierSpec,
    HNSWGraph, RecencyTierManager, TierBoundary,
    MorphingVectorIndex, FlatIndex,
)
from core.theory import validate_monotonic_error


def test_quantizer_roundtrip_shape():
    rng = np.random.default_rng(0)
    data = rng.standard_normal((100, 16)).astype(np.float32)
    spec = TierSpec("t", n_subquantizers=4, bits=4)
    pq = ProductQuantizer(16, spec, seed=1).fit(data)
    codes = pq.encode(data)
    assert codes.shape == (100, 4)
    recon = pq.decode(codes)
    assert recon.shape == data.shape


def test_quantizer_error_bounded_by_zero_at_perfect_recall():
    rng = np.random.default_rng(0)
    data = rng.standard_normal((50, 8)).astype(np.float32)
    spec = TierSpec("t", n_subquantizers=8, bits=8)  # very fine relative to n=50
    pq = ProductQuantizer(8, spec, seed=1).fit(data)
    err = pq.reconstruction_error(data)
    assert err >= 0.0


def test_tiered_quantizer_monotonic_error():
    rng = np.random.default_rng(2)
    data = rng.standard_normal((400, 32)).astype(np.float32)
    specs = [
        TierSpec("hot", 16, 8),
        TierSpec("warm", 8, 5),
        TierSpec("cold", 2, 4),
    ]
    tq = TieredQuantizer(32, specs, seed=3).fit(data)
    errors = validate_monotonic_error(tq, data)  # raises AssertionError if violated
    assert len(errors) == 3


def test_graph_insert_and_search_self():
    rng = np.random.default_rng(4)
    dim = 16
    idx = HNSWGraph(dim, M=8, ef_construction=32, seed=5)
    data = rng.standard_normal((30, dim)).astype(np.float32)
    for i in range(30):
        idx.insert(i, data[i])
    res = idx.search(data[5], k=1, ef=30)
    assert res[0][0] == 5, "exact self-lookup should return itself as nearest"


def test_tier_manager_assigns_coldest_after_long_idle():
    boundaries = [
        TierBoundary(max_age=10, tier_index=0, target_recall=0.9),
        TierBoundary(max_age=50, tier_index=1, target_recall=0.7),
        TierBoundary(max_age=float("inf"), tier_index=2, target_recall=0.5),
    ]
    mgr = RecencyTierManager(boundaries, migration_batch_size=100)
    mgr.register(vid=1, tick=0.0)
    assert mgr.current_tier[1] == 0
    migrations = mgr.due_migrations(tick=100.0)
    assert any(vid == 1 and new_tier == 2 for vid, _, new_tier in migrations), \
        "vector idle for 100 ticks should migrate to the coldest tier"


def test_tier_manager_touch_keeps_vector_hot():
    boundaries = [
        TierBoundary(max_age=10, tier_index=0, target_recall=0.9),
        TierBoundary(max_age=50, tier_index=1, target_recall=0.7),
        TierBoundary(max_age=float("inf"), tier_index=2, target_recall=0.5),
    ]
    mgr = RecencyTierManager(boundaries, migration_batch_size=100)
    mgr.register(vid=1, tick=0.0)
    mgr.touch(vid=1, tick=8.0)   # accessed again before the tier-0 boundary
    migrations = mgr.due_migrations(tick=15.0)  # 15 - 8 = 7 < 10, still fresh
    assert not any(vid == 1 for vid, _, _ in migrations), \
        "a recently-touched vector should not migrate just because it's old since insertion"


def test_end_to_end_index_runs_without_error():
    rng = np.random.default_rng(6)
    dim = 16
    data = rng.standard_normal((150, dim)).astype(np.float32)
    specs = [TierSpec("hot", 8, 6), TierSpec("warm", 4, 5), TierSpec("cold", 2, 4)]
    boundaries = [
        TierBoundary(30, 0, 0.9), TierBoundary(80, 1, 0.7), TierBoundary(float("inf"), 2, 0.5)
    ]
    idx = MorphingVectorIndex(dim, specs, boundaries, migration_batch_size=5, seed=7)
    idx.fit_quantizers(data[:60])
    for i in range(150):
        idx.insert(i, data[i])
    res = idx.query(data[10], k=5)
    assert len(res) == 5
    stats = idx.stats()
    assert stats["n_vectors"] == 150
    assert sum(stats["tier_distribution"].values()) == 150


def test_migration_reduces_storage_footprint_vs_flat_fine():
    rng = np.random.default_rng(8)
    dim = 16
    data = rng.standard_normal((300, dim)).astype(np.float32)
    specs = [TierSpec("hot", 8, 8), TierSpec("warm", 4, 5), TierSpec("cold", 2, 3)]
    boundaries = [
        TierBoundary(20, 0, 0.9), TierBoundary(80, 1, 0.7), TierBoundary(float("inf"), 2, 0.5)
    ]
    morph = MorphingVectorIndex(dim, specs, boundaries, migration_batch_size=10, seed=9)
    morph.fit_quantizers(data[:100])
    for i in range(300):
        morph.insert(i, data[i])

    flat = FlatIndex(dim, specs[0], seed=9)
    flat.fit_quantizer(data[:100])
    for i in range(300):
        flat.insert(i, data[i])

    assert morph.stats()["total_storage_bytes"] < flat.total_storage_bytes(), \
        "tiered storage should be smaller than always-fine-precision storage once vectors age"


if __name__ == "__main__":
    tests = [v for k, v in list(globals().items()) if k.startswith("test_")]
    failures = 0
    for t in tests:
        try:
            t()
            print(f"PASS: {t.__name__}")
        except Exception as e:
            failures += 1
            print(f"FAIL: {t.__name__}: {e}")
    print(f"\n{len(tests) - failures}/{len(tests)} passed")
    sys.exit(1 if failures else 0)
