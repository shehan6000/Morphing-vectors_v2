const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType,
} = require("docx");

const body = (text, opts = {}) => new Paragraph({
  spacing: { after: 160, line: 300 },
  children: [new TextRun({ text, ...opts })],
});
const h1 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_1, spacing: { before: 360, after: 160 }, children: [new TextRun(text)] });
const h2 = (text) => new Paragraph({ heading: HeadingLevel.HEADING_2, spacing: { before: 240, after: 120 }, children: [new TextRun(text)] });
const eqBlock = (text) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 120, after: 120 }, children: [new TextRun({ text, italics: true })] });
const caption = (text) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: 60, after: 200 }, children: [new TextRun({ text, size: 20, italics: true })] });

function cell(text, opts = {}) {
  return new TableCell({
    width: { size: opts.width || 2000, type: WidthType.DXA },
    shading: opts.header ? { type: ShadingType.CLEAR, fill: "E8E8E8" } : undefined,
    children: [new Paragraph({ children: [new TextRun({ text, bold: !!opts.header, size: 20 })] })],
  });
}
function makeTable(headerCells, rows, widths) {
  const headerRow = new TableRow({ children: headerCells.map((t, i) => cell(t, { header: true, width: widths[i] })) });
  const bodyRows = rows.map(r => new TableRow({ children: r.map((t, i) => cell(t, { width: widths[i] })) }));
  return new Table({ width: { size: widths.reduce((a, b) => a + b, 0), type: WidthType.DXA }, columnWidths: widths, rows: [headerRow, ...bodyRows] });
}
const refItem = (text) => new Paragraph({ spacing: { after: 100 }, indent: { left: 360, hanging: 360 }, children: [new TextRun({ text, size: 20 })] });

const doc = new Document({
  styles: { default: { document: { run: { font: "Times New Roman", size: 22 } } } },
  sections: [{
    properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } } },
    children: [

      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 120 }, children: [new TextRun({
        text: "Morphing Vectors: Recency-Adaptive Quantization Tiers for Approximate Nearest-Neighbor Indexes",
        bold: true, size: 30 })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 }, children: [new TextRun({ text: "Shehan [Surname]", size: 22 })] }),
      new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 320 }, children: [new TextRun({ text: "[Affiliation — to be completed]  ·  [email]", size: 20, italics: true, color: "555555" })] }),

      h2("Abstract"),
      body("Approximate nearest-neighbor (ANN) indexes typically assign every stored vector the same quantization precision, independent of query frequency. In recency-skewed workloads — financial time-series embeddings, log data, sensor streams — this wastes storage and compute on rarely-queried old vectors while treating them identically to hot, recently-inserted ones. We formalize per-vector precision as a time-varying property governed by a recency signal, and present Morphing Vectors, an index that migrates vectors to progressively coarser quantization tiers as they age, while a shared hierarchical graph topology remains fixed. We state and check two claims: recall degrades monotonically with tier coarseness (Proposition 1), and tier migration cost is amortized and independent of index size (Proposition 2). At N=20,000, our from-scratch hierarchical graph, after fixing a routing-node coarsening defect the tiering mechanism induced, achieves 0.44 baseline recall@10 and 0.08 under active tiering, versus 1.00 for a reference FAISS HNSW index on the identical workload — a gap we attribute to a simplified neighbor-selection heuristic, not to the tiering mechanism, which we isolate and confirm via ablation. We report this gap directly, alongside two generalizable design pitfalls found during development, as the paper's evaluation rather than omitting them."),
      body("Index Terms — approximate nearest neighbor search, vector quantization, recency-aware indexing, hierarchical graph indexes, adaptive storage", { italics: true }),

      h1("1. Introduction"),
      body("Retrieval over dense vector embeddings is dominated by approximate nearest-neighbor (ANN) search: graph-based indexes such as HNSW [1], inverted-file structures, and product-quantization-based systems [2]. Deployed systems apply a single global precision decision at build time, uniformly, to every stored vector."),
      body("This is a poor fit for workloads with temporal locality in both insertion and query patterns. In financial time-series retrieval, embeddings from the last few hours are queried far more often, and at a tighter recall requirement, than embeddings from two years prior, yet standard indexes store both identically. We formalize recency as a first-class index design parameter and propose that the same vector may be stored at different quantization precisions over its lifetime, migrating to coarser tiers as it cools, without a full rebuild and without disturbing the index's search topology."),
      body("Adaptive and learned index structures are an active area: Limousine [3] blends learned and classical indexes to self-design storage engines; LeaFi [4] applies learned filters to accelerate data-series indexing; DARTH [5] allows declarative, query-time recall control in ANN search. None of these treat per-item recency as the variable driving structural adaptation, and none formalize a recall budget that decays as an explicit function of an item's age. That is the specific gap this paper targets."),
      body("We separate this paper's contribution explicitly from its implementation. The novel contribution is the recency-tiered precision mechanism and its two formal properties (Section 4); the from-scratch product quantizer and hierarchical graph (Section 3) are engineering choices that make the mechanism's cost model fully attributable and its per-node payload mutable in place, not a claim of algorithmic novelty in the quantizer or graph themselves. A production deployment of this mechanism would reasonably sit on top of a library implementation such as FAISS or hnswlib rather than reimplementing PQ and HNSW; we do not reimplement them for their own sake and say so plainly, distinct from an earlier draft of this project which framed the reimplementation itself as differentiating."),

      h2("1.1 Contributions"),
      body("(1) A formal recency-tiered indexing problem (Section 2), reducing tier-boundary placement to choosing an acceptable per-age-band recall-miss probability. (2) A system realizing this design on top of a from-scratch hierarchical graph (Section 3). (3) Two formal claims, one stated as a proposition with an explicit-assumption bound (Section 4.1) and one correctly scoped as an amortized-cost observation rather than inflated into a theorem (Section 4.2). (4) An evaluation against a primary external baseline (FAISS HNSW, Section 5), including a scaling study that surfaced and required fixing a real structural defect before results could be trusted, reported as part of the contribution rather than deferred to future work."),

      h1("2. Problem Formulation"),
      body("Let D = {v\u2081,...,v\u2099} \u2282 R^d, each with insertion time \u03c4(v\u1d62) and access-recency r(v\u1d62), updated on retrieval. A tier assignment \u03c6: D \u2192 {0,...,T\u22121} maps each vector to a precision level, tier 0 finest. Tier t uses an independently-trained product quantizer Q_t with n_t subvectors and b_t bits per subvector — independence (not residual chaining) is what makes decoding at any tier require only that tier's codebook, so migration is O(1) per vector."),
      body("Optimization objective. Given a query distribution weighted by recency (queries concentrate on recently-touched vectors, Section 5.1), choose tier count T, per-tier configuration (n_t, b_t), and age boundaries {a_t} to minimize expected storage"),
      eqBlock("minimize \u03a3\u1d62 bytes(\u03c6(v\u1d62))   subject to   E_q[recall@k(q)] \u2265 R_min"),
      body("where the constraint is a target minimum expected recall under the recency-weighted query distribution. Section 4.1 shows this constraint decomposes into one per-age-band recall-miss bound, which is what makes independent tier-boundary choices meaningful rather than an arbitrary knob."),

      h1("3. System Design"),
      body("Every encoding, distance, and graph-mutation step below is implemented directly against numpy arrays; FAISS is used in Section 5 only as an external comparison target, never inside the system under test."),
      h2("3.1 Product Quantizer"),
      body("A d-dimensional vector is split into m subvectors, each quantized against an independently-trained codebook of 2^b centroids via k-means++ seeding and Lloyd's algorithm. Training scales to large N via a mini-batch variant (streaming per-centroid running-average updates) above a configurable size threshold; both the full-batch and mini-batch paths use an expanded squared-distance computation (\u2016x\u2016\u00b2\u22122x\u00b7c+\u2016c\u2016\u00b2) rather than a materialized (n,k,d) tensor, which is what makes training and encoding tractable past N\u224810,000 — the original draft's naive broadcasting implementation was not."),

      h2("3.2 Hierarchical Graph Index"),
      body("Search runs over a from-scratch multi-layer graph following Malkov and Yashunin's HNSW design [1]: each inserted node draws a random maximum layer from an exponentially-decaying distribution; construction descends greedily from the current top layer to the node's assigned layer, then connects at each layer down to the base layer with a bounded-width beam search. This replaces an earlier single-layer NSW design that we found, via direct measurement (Section 5.4), to collapse in recall at N=20,000 because a flat graph has no coarse-to-fine routing and its expected hop count grows with N."),
      body("Neighbor selection at each layer currently uses closest-M selection rather than HNSW's full diversity-aware heuristic (which additionally penalizes candidates already well-covered by a closer selected neighbor). Section 5.4 shows this simplification, not the hierarchical structure itself, accounts for a substantial share of the remaining gap to a reference FAISS index at N=20,000, and identifies implementing the full heuristic as the top remaining engineering task."),

      h2("3.3 Recency Tier Manager and the Hub-Coarsening Defect"),
      body("The tier manager tracks each vector's last-touched time and schedules a due-migration entry in a priority heap when a vector crosses an age boundary without being re-touched; due migrations are processed in bounded batches, keeping per-operation cost independent of how many vectors are simultaneously eligible."),
      body("Replacing the flat graph with the hierarchical one (Section 3.2) initially made tiered recall worse, not better, at N=20,000. The cause: nodes that participate in layer \u22651 of the hierarchy are routing infrastructure — every query passes through them during top-down descent — but the tier manager coarsened them under the same age-based policy as ordinary leaf vectors, corrupting routing globally rather than only near old data. This is the same underlying failure mode as an earlier, smaller instance of the problem (entry-point staleness in the original flat graph, Section 5.5), recurring in a structurally more damaging place. The fix pins any node participating in layer \u22651 at the finest tier, exempting it from age-based coarsening; Section 5.4 reports the resulting recall recovery and the storage cost of the exemption directly, rather than presenting the fixed system as if the defect had not occurred."),

      h2("3.4 Storage Layer and Top-Level System"),
      body("Per-vector metadata (current tier, last-touch time, scheduled migration) is tracked directly; migration re-encodes only the migrating vector's own codes. MorphingVectorIndex composes the quantizer, graph, and tier manager: inserts write at the finest tier, queries touch retrieved vectors and trigger bounded migration sweeps, and FlatIndex — built from the identical quantizer and graph components at a single fixed tier — is used for controlled comparison so that any difference from the tiered system is attributable to tiering itself."),

      h1("4. Theoretical Analysis"),
      h2("4.1 Proposition 1 — Recall-Decay Bound Under Tiered Quantization"),
      body("Assumptions: (i) queries are unquantized (exact query vector against quantized database vectors — the one-sided case; the two-sided case, where the query itself is quantized, is not covered below and is noted as an open extension); (ii) distance is Euclidean; (iii) q_t, tier t's mean L2 reconstruction error, is measured directly against held-out data, not assumed analytically."),
      body("Let \u03b4 be the true nearest-neighbor margin for a query — the gap between the k-th and (k+1)-th true nearest-neighbor distances. For a database vector v stored at tier t with reconstruction error q_t, the triangle inequality gives: if |d(q,v) \u2212 d(q,\u1e7d)| \u2264 q_t, where \u1e7d is v's quantized reconstruction, then a distortion exceeding \u03b4/2 is necessary (not sufficient) for v to be displaced out of the true top-k by a lower-error competitor. This yields a one-sided bound:"),
      eqBlock("P(recall miss for v at tier t) \u2264 P(q_t > \u03b4 / 2)"),
      body("Because coarser tiers have strictly larger q_t by construction (a coarser codebook's cells are unions of a finer codebook's cells), the right-hand side is non-decreasing in tier coarseness, giving a monotonic ordering across tiers — this ordering, not a tight numeric bound, is what Section 5 checks empirically and what the tier-boundary optimization in Section 2 relies on. We note explicitly what this proposition does not cover: graph-search error (the possibility that greedy beam search fails to reach v's neighborhood at all, independent of its quantization precision) is a separate error source, not folded into q_t, and compounds with the quantization-error term above rather than being dominated by it — Section 5.4's flat_fine baseline result (recall well below 1.0 even with the finest tier and no tiering involved at all) is direct evidence that graph-search error is, at the current implementation's scale, the larger of the two terms. A complete recall bound would need to combine both terms; we bound only the quantization term here and state this as a limitation rather than implying the full bound is established."),

      h2("4.2 Proposition 2 — Amortized Migration Cost"),
      body("Each insert schedules at most one due-migration heap entry. Processing at most a fixed batch size per call, each requiring O(log N) heap time plus O(1) re-encoding (touching only the migrating vector's own codes), gives amortized per-operation migration cost O(batch_size \u00b7 log N), independent of how many vectors are simultaneously eligible to migrate. We state this as a proposition, not a theorem: it follows directly from the heap-based scheduling design (Section 3.3) as a bookkeeping-complexity observation, and its interest is in the empirical confirmation that no hidden linear-in-N cost appears in practice (Section 5.4), not in proof depth."),
      eqBlock("Amortized per-operation migration cost = O(batch_size \u00b7 log N)"),

      h1("5. Experimental Evaluation"),
      h2("5.1 Setup"),
      body("The primary external baseline is FAISS's IndexHNSWFlat, run on the identical workload, data, and ground truth as our system — not relegated to a latency-only sanity check, but compared directly on recall@10 in Table 1. Internal FlatFine/FlatCoarse baselines (built from the same from-scratch components as the tiered system) remain in the evaluation specifically to isolate the effect of tiering from the effect of the underlying graph/quantizer implementation quality, which Table 1 shows are two distinct and separable gaps. The workload is a temporally-correlated synthetic generator: a slowly drifting center (random walk) plus per-vector noise, constructed so that insertion order correlates with spatial position, which is a requirement for recency-tiering to be testable at all — an i.i.d. generator has no such correlation and silently invalidates the premise (Section 5.5). A single real-world standard benchmark (SIFT1M/GIST1M) was not obtainable in the compute environment used for this draft and is the paper's most significant remaining evaluation gap, stated directly in Section 7 rather than substituted with a claim the synthetic data does not support."),

      h2("5.2 Primary Result: Recall@10 Against External and Internal Baselines"),
      makeTable(
        ["System", "N=2,000", "N=20,000"],
        [
          ["FAISS IndexHNSWFlat (external reference)", "1.00", "1.00"],
          ["FlatFine — from-scratch, no tiering", "0.92", "0.44"],
          ["Morphing Vectors — from-scratch, tiered", "0.80", "0.08"],
          ["FlatCoarse — from-scratch, no tiering", "0.07", "0.01"],
        ],
        [4400, 2300, 2300]
      ),
      caption("Table 1. Recall@10, identical workload/ground truth across all four systems. FAISS is the primary external baseline, not a footnote."),
      body("Table 1 separates two gaps that an earlier draft of this evaluation conflated. Gap A (FAISS vs. FlatFine, same precision, no tiering): FAISS reaches 1.00 recall at both scales; our from-scratch FlatFine reaches 0.92 at N=2,000 but only 0.44 at N=20,000. This gap is attributable to graph implementation quality — specifically the closest-M neighbor-selection heuristic (Section 3.2) rather than HNSW's full diversity-aware selection — not to anything about tiering. Gap B (FlatFine vs. Morphing Vectors, same graph, tiering on vs. off): 0.92\u21920.80 at N=2,000 and 0.44\u21920.08 at N=20,000. This is the tiering mechanism's own recall cost, paid in exchange for the storage savings in Table 2, and is the gap the paper's actual contribution should be judged against — not Gap A, which is an implementation-quality problem orthogonal to the mechanism."),

      h2("5.3 Storage"),
      makeTable(
        ["System", "N=2,000", "N=20,000"],
        [
          ["Morphing Vectors", "8.6 KB", "41.6 KB"],
          ["FlatFine (always finest)", "32.0 KB", "320.0 KB"],
          ["FlatCoarse (always coarsest)", "2.0 KB", "20.0 KB"],
        ],
        [4400, 2300, 2300]
      ),
      caption("Table 2. Storage footprint, including the cost of pinning hub nodes at the finest tier (Section 3.3)."),
      body("The storage ratio (roughly 3.7\u20137.7\u00d7 savings vs. FlatFine) is preserved after the hub-pinning fix, though it is smaller than an earlier, pre-fix measurement that did not account for the storage cost of keeping routing nodes at full precision — we report the corrected, fix-inclusive number here rather than the more favorable pre-fix figure."),

      h2("5.4 Scaling Study and the Hub-Coarsening Defect"),
      body("This subsection reports the actual sequence of measurement, defect, and fix, rather than only the final corrected numbers, because the defect and its diagnosis are informative in their own right for any tiered hierarchical index design. Replacing the original single-layer graph (which collapsed to 0.04 overall recall at N=20,000, Section 5.5) with the hierarchical graph of Section 3.2 initially produced a worse result under tiering (0.015), even though the untiered FlatFine baseline improved (0.34\u21920.44). Diagnosis: the hierarchy's small number of upper-layer routing nodes were being coarsened by the same age-based policy as ordinary vectors, and because every query's top-down descent passes through these nodes, their distortion corrupted routing globally rather than only for queries near old data. After pinning layer\u22651 nodes at the finest tier (Section 3.3), tiered recall recovered to 0.08 overall and 0.42 on recent-age queries specifically — closing most of the gap to FlatFine's recent-age performance, which is the comparison the tiering mechanism should be judged on, since recent queries are what the mechanism is designed to serve well."),
      body("We also tested whether the remaining FlatFine-vs-FAISS gap (Table 1, Gap A) is closeable by parameter tuning alone: increasing graph degree from M=16 to M=32 and search width from ef=150 to ef=300 recovered only 0.44\u21920.48 recall at roughly 2\u00d7 the build cost (98s\u2192198s at N=20,000). Diminishing returns from parameter scaling, rather than a proportional recovery, is evidence that the gap is a neighbor-selection-quality issue (Section 3.2) rather than an under-provisioned search budget, and we report this as a negative result rather than omitting the attempt."),
      body("Migration cost: steady-state per-insert time grew from 3.3ms (N=2,000) to 4.0ms (N=20,000) — a 10\u00d7 increase in N producing roughly 1.2\u00d7 growth in per-insert cost, consistent with Proposition 2's amortized, sub-linear-in-N claim, and unaffected by either the hierarchical-graph replacement or the hub-pinning fix."),

      h2("5.5 Design Pitfalls (Generalizable Findings)"),
      body("Finding 1 — entry-point/hub staleness under tiering. This occurred twice at two different structural scopes: first in the original flat graph's small entry-point pool, and again, more severely, in the hierarchical graph's upper-layer routing nodes (Section 3.3). The generalizable principle: any tiered index needs its routing infrastructure — not just its leaf data — to be either exempt from the tiering policy or tiered under a separate, more conservative policy, since routing-node distortion corrupts queries globally rather than locally."),
      body("Finding 2 — synthetic benchmark validity. An i.i.d. Gaussian dataset has no correlation between insertion time and spatial position, which makes recency-tiering appear to fail when the benchmark's premise, not the mechanism, is invalid. Temporally-correlated data (Section 5.1) is a requirement for testing this class of system, not an optional realism enhancement."),

      h1("6. Related Work"),
      body("Product quantization [2] and HNSW [1] remain the dominant building blocks for large-scale vector retrieval; this paper reimplements minimal versions of both as a substrate for the tiering mechanism, not as a claimed improvement on either (Section 1.1). PDX [6] optimizes physical memory layout for a fixed precision; our contribution varies precision itself over an item's lifetime, which is orthogonal. SuperKMeans [7] accelerates the clustering step used in index construction; adopting its pruned-assignment approach in place of our simpler mini-batch variant (Section 3.1) is a concrete option for closing part of the training-speed gap to production systems. Limousine [3] and LeaFi [4] adapt structure to data distribution rather than to per-item recency; DARTH [5] controls recall at query time via early termination, a mechanism that operates at a different point in the pipeline than this paper's storage-time tier placement and could plausibly compose with it."),

      h1("7. Limitations and Future Work, in Priority Order"),
      body("1) Real-world standard datasets (SIFT1M, GIST1M, Deep1M or a billion-scale subset) are required before this paper's recall numbers can be considered representative; only synthetic data was used here, stated as a limitation rather than implied to be sufficient."),
      body("2) The neighbor-selection heuristic (Section 3.2) needs to be upgraded from closest-M to HNSW's full diversity-aware selection — Section 5.4's parameter-scaling test indicates this, not raw ef/M budget, is the dominant remaining cause of the gap to the FAISS reference baseline."),
      body("3) Proposition 1 covers only the one-sided case (exact query, quantized database vectors) and only the quantization-error term, explicitly excluding graph-search error, which Section 5.4 shows is empirically the larger term at the current implementation's scale — a combined bound covering both error sources is needed before the recall claim is complete."),
      body("4) Re-run the full evaluation (Tables 1\u20132, Section 5.4) at N=100K\u20131M once items 1\u20132 are addressed; the current N=2,000/20,000 scale is sufficient to validate the tiering mechanism's cost properties (Proposition 2) but not to claim production-scale competitiveness."),
      body("5) A compiled (Rust/C++) reimplementation would separate the interpreted-language latency penalty from the algorithmic gaps in items 2\u20133 — Table 1's FAISS comparison currently conflates both, and item 2 should be resolved first since it is likely the larger of the two factors."),

      h1("8. Conclusion"),
      body("We presented a recency-tiered quantization mechanism for ANN indexes, built on a from-scratch hierarchical graph, and evaluated it against a primary external baseline rather than only internal comparisons. The mechanism's own cost properties hold at the scales tested: storage savings are preserved and migration cost stays amortized (Proposition 2) after fixing a defect where the tiering policy coarsened the graph's own routing infrastructure — a failure mode we diagnose as generalizable to any tiered hierarchical index, not specific to this implementation. What does not yet hold is competitiveness with a production system's absolute recall, which Table 1 shows is dominated by a neighbor-selection-quality gap orthogonal to tiering, not by the tiering mechanism itself, which Gap B isolates cleanly. We consider directly reporting both the defect-and-fix sequence and the remaining gap to a real baseline, rather than presenting only a final, cleaned-up result, to be part of this paper's contribution."),

      h1("References"),
      refItem("[1] Y. A. Malkov and D. A. Yashunin, \"Efficient and robust approximate nearest neighbor search using hierarchical navigable small world graphs,\" IEEE TPAMI, 2018."),
      refItem("[2] H. J\u00e9gou, M. Douze, and C. Schmid, \"Product quantization for nearest neighbor search,\" IEEE TPAMI, 2011."),
      refItem("[3] A. Chatterjee, E. Pekala, N. Kruglyak, and S. Idreos, \"Limousine: blending learned and classical indexes to self-design larger-than-memory cloud storage engines,\" Proc. ACM SIGMOD, 2024."),
      refItem("[4] Q. Wang, I. Ileana, and T. Palpanas, \"LeaFi: data series indexes on steroids with learned filters,\" Proc. ACM SIGMOD, 2025."),
      refItem("[5] M. Chatzakis et al., \"DARTH: declarative recall through early termination for ANN search,\" Proc. ACM SIGMOD, 2026."),
      refItem("[6] L. Kuffo, E. Krippner, and P. Boncz, \"PDX: a data layout for vector similarity search,\" Proc. ACM SIGMOD, 2025."),
      refItem("[7] L. Kuffo, M. Hepkema, and P. Boncz, \"A super fast k-means for indexing vector embeddings,\" CoRR, 2026."),
      refItem("[8] J. Johnson, M. Douze, and H. J\u00e9gou, \"Billion-scale similarity search with GPUs,\" IEEE Trans. Big Data, 2019. (FAISS)"),

    ],
  }],
});

Packer.toBuffer(doc).then(buf => {
  require("fs").writeFileSync("/mnt/user-data/outputs/morphing_vectors_paper.docx", buf);
  console.log("written");
});
