# Morphing Vectors

**Recency-Adaptive, Self-Contained Vector Indexing for Time-Varying Access Patterns**

A from-scratch implementation (no FAISS, no hnswlib, no scikit-learn) built to
support a TKDE submission that extends the [Morphing Pages] encoding-transition
idea from columnar storage into vector indexing, and connects to the [QUANT-DB]
hybrid SQL/semantic query engine as the shared architectural thread across both
papers.

[Morphing Pages]: ../morphing-pages-paper.md
[QUANT-DB]: ../quant-db.md

## The idea, in one paragraph

Standard ANN indexes (HNSW, IVF, PQ-based systems) apply one fixed precision to
every stored vector regardless of how often or how recently it's queried. In
recency-skewed workloads — financial time series, logs, sensor streams — that
wastes storage on data nobody queries and doesn't need to: this system tracks
per-vector access recency and lazily migrates each vector to a coarser
quantization tier as it ages, without ever rebuilding the search graph. The
search graph's *topology* stays fixed; only the *precision* of what's attached
to each node changes.

## Why everything is built from scratch

The TKDE framing this project targets requires the contribution to be fully
owned and theoretically characterizable — not "FAISS + a scheduler." Every
component below is implemented directly on numpy with no ANN/clustering
library dependency:

| Component | File | What's custom |
|---|---|---|
| Product quantizer | `core/quantizer.py` | k-means++ seeding, Lloyd's algorithm, encode/decode, error tracking — all hand-written, no sklearn |
| Graph search structure | `core/graph_index.py` | Navigable Small World graph: insertion, pruning, multi-entry-point greedy search — no hnswlib/FAISS |
| Recency → tier policy | `core/tiers.py` | **This is the actual novel contribution.** Recency tracking, tier-boundary assignment, amortized lazy migration scheduling |
| Storage layer | `core/storage.py` | Per-vector encoding metadata and targeted re-encoding — the vector-index analogue of Morphing Pages' column encoding transitions |
| Theory | `core/theory.py` | Formal claims (recall-decay bound, amortized migration cost) with pointers to their empirical checks |

Using well-known base algorithms (product quantization, NSW graphs)
implemented yourself is not the same as depending on a library for them —
every arithmetic step here is inspectable and was specifically written so the
tier-migration engine can hook into it (e.g. `NSWIndex.update_vector` for O(1)
in-place precision swaps, which a library's opaque index wouldn't expose).

## Results (synthetic benchmark, `eval/benchmark.py`)

Run: `python3 -m eval.benchmark`

Dataset: 1,500 32-dim vectors with **temporal locality** — a slowly drifting
center plus per-vector noise, mimicking regime persistence in financial
time-series embeddings (see the docstring in `temporally_correlated_data()`
for why this matters: pure i.i.d. vectors have no recency structure at all,
which silently invalidates the whole premise — this was caught and fixed
during development, see "Honest findings" below).

| System | Recall@10 (recent queries) | Recall@10 (old queries) | Storage |
|---|---|---|---|
| MorphingVectorIndex | **0.52** | 0.09 | **6.0 KB** |
| FlatIndex (always-fine) | 0.51 | 0.51 | 24.0 KB |
| FlatIndex (always-coarse) | 0.00 | 0.00 | 1.5 KB |

The headline result: on recent queries, the tiered system **matches the
always-fine baseline's recall at 1/4 the storage**, while the always-coarse
baseline gets essentially nothing right anywhere. Recall degrades on old
queries as expected — that's the accepted trade-off the recency-tier boundary
choice encodes, not a flaw.

Migration cost scaling (`eval/scaling_test.py`, Theorem 2 check): steady-state
per-insert migration overhead stays flat (~1.2-1.35ms) across a 16x increase
in N (500 → 8,000 vectors) — supports the amortized, not-linear-in-N, cost
claim.

## Honest findings from building this (worth keeping in the paper's evaluation section)

Two real bugs surfaced during development that are more interesting than they
sound — they're exactly the kind of design pitfall a TKDE reviewer would probe
for, so documenting them (with the fix) strengthens the paper rather than
weakening it:

1. **Entry-point staleness under tiering.** A graph search needs a starting
   node. The obvious choice — the first few inserted nodes, which tend to be
   well-connected hubs in an NSW graph — turned out to be exactly the wrong
   choice here: under recency-based tiering, the earliest-inserted nodes are
   the *first* to migrate to the coarsest precision, so every search started
   from maximally distorted distance estimates regardless of query content.
   Fixed by mixing in a random sample from a sliding recent-insertion window
   as additional entry points (`NSWIndex._entry_pool`). This is a genuine
   design principle worth stating explicitly in the paper: **any tiered index
   needs entry/routing structures that are tier-aware, not just the data
   nodes.**

2. **Synthetic benchmark validity.** An i.i.d. Gaussian synthetic dataset has
   zero correlation between insertion time and spatial position, so a
   "recent" query's true nearest neighbors are scattered uniformly across all
   ages — including long-cold ones — which makes recency-tiering look like it
   fails when actually the benchmark's premise was invalid. Fixed by
   generating data with a slow random-walk drift (temporal locality), which
   is also a more faithful model of financial regime persistence than i.i.d.
   noise would be. **Any evaluation of this idea must use temporally
   correlated data, or the entire tiering premise is untestable.**

## Repo layout

```
morphing_vectors/
├── core/
│   ├── quantizer.py     # ProductQuantizer, TieredQuantizer (from-scratch PQ)
│   ├── graph_index.py   # NSWIndex (from-scratch NSW graph)
│   ├── tiers.py         # RecencyTierManager (the novel contribution)
│   ├── storage.py       # MorphingStorage (per-vector encoding state)
│   ├── index.py         # MorphingVectorIndex (top-level system)
│   ├── baseline.py      # FlatIndex (fair same-components baseline)
│   └── theory.py        # Theorem statements + numeric validators
├── eval/
│   ├── benchmark.py     # main recall/storage benchmark + workload generator
│   └── scaling_test.py  # amortized migration cost scaling check
├── tests/
│   └── test_basic.py    # 8 correctness tests, all passing
└── README.md
```

## Mapping to the TKDE paper structure

| Paper section | Backing code |
|---|---|
| §3 System Design — custom quantizer | `core/quantizer.py` |
| §3 System Design — graph/cluster index | `core/graph_index.py` |
| §3 System Design — tier-migration engine | `core/tiers.py` |
| §3 System Design — storage layer (ties to Morphing Pages) | `core/storage.py` |
| §4 Theoretical Analysis — Theorem 1 (recall-decay bound) | `core/theory.py::validate_monotonic_error` |
| §4 Theoretical Analysis — Theorem 2 (amortized migration cost) | `eval/scaling_test.py` |
| §5 Experimental Evaluation | `eval/benchmark.py` |
| §5 Ablations (fixed-tier vs adaptive) | `core/baseline.py::FlatIndex` vs `core/index.py::MorphingVectorIndex` |

## Next steps toward submission-ready

1. **Scale up the benchmark.** Current results are at N=1,500 for iteration
   speed. Before writing up results, re-run at N=100K-1M (the k-means steps in
   `quantizer.py` are O(n·k) per iteration — will need either mini-batch
   k-means or a coarser subsample for training at that scale; searching is
   already sub-linear via the graph).
2. **Add the standard ANN benchmark datasets** (SIFT1M, GIST1M) alongside the
   synthetic temporally-correlated set, so reviewers can sanity-check absolute
   competitiveness against FAISS/DiskANN even though this system doesn't
   depend on them.
3. **Formalize and prove Theorem 1 properly** (currently stated with a sketch
   proof and an empirical monotonicity check — a TKDE submission needs the
   full derivation, ideally reusing the PAC-Bayes calibration machinery from
   QANC-DB).
4. **Pull in a real financial time-series embedding dataset** from QUANT-DB's
   pipeline to replace/complement the synthetic drift-based generator, which
   would let one evaluation section serve both papers' narratives.
5. **Multi-threaded / production-grade re-implementation** in Rust or C++ if
   the paper's systems contribution needs to demonstrate competitive absolute
   latency, not just the relative tiering effect (Python/numpy is fine for
   proving the idea, not for a systems-track performance table).
